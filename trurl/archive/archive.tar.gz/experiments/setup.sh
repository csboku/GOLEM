#!/bin/bash
# Setup script for TRURL
echo "Setting up TRURL NetCDF Viewer..."

# Make sure we're in the project directory
cd "$(dirname "$0")"

# Install dependencies
echo "Installing dependencies..."
julia --project -e 'using Pkg; Pkg.resolve(); Pkg.instantiate()'

echo "Setup complete!"
echo "Run the application with: julia --project src/main.jl"