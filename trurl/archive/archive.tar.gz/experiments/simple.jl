using Gtk
using Dates

# Create a simple window to verify that GTK is working properly
win = GtkWindow("TRURL - NetCDF Viewer", 400, 300)

# Create a vertical box layout
vbox = GtkBox(:v)
push!(win, vbox)

# Add a label
label = GtkLabel("This is a simple test window to verify that GTK is working.")
set_gtk_property!(label, :margin, 10)
push!(vbox, label)

# Add a button
button = GtkButton("Click me")
set_gtk_property!(button, :margin, 10)
push!(vbox, button)

# Connect signal to button
signal_connect(button, "clicked") do widget
    println("Button clicked!")
    set_gtk_property!(label, :label, "Button was clicked at $(now())")
end

# Show all widgets
showall(win)

# Keep the application running
if !isinteractive()
    @async Gtk.gtk_main()
    Gtk.waitforsignal(win, :destroy)
end