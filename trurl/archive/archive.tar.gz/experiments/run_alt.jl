using Gtk
using Gtk.ShortNames
using GtkReactive
using CairoMakie
using NCDatasets
using Printf

# Import a simpler version that doesn't use module structure
# and just creates and shows the GUI

struct NCData
    filename::String
    variables::Vector{String}
    dimensions::Dict{String, Int}
    data::Dict{String, Array}
end

function load_netcdf(filename::String)
    ds = NCDataset(filename)
    variables = keys(ds) |> collect
    dimensions = Dict{String, Int}()
    data = Dict{String, Array}()
    
    for dim in keys(ds.dim)
        dimensions[dim] = ds.dim[dim]
    end
    
    for var in variables
        data[var] = ds[var][:]
    end
    
    close(ds)
    return NCData(filename, variables, dimensions, data)
end

function get_variable_data(nc_data::NCData, variable::String)
    return nc_data.data[variable]
end

function get_variable_dimensions(nc_data::NCData, variable::String)
    return size(nc_data.data[variable])
end

function create_plot(data::Array, title::String="", xlabel::String="X", ylabel::String="Y")
    f = Figure(resolution=(800, 600))
    ax = Axis(f[1, 1], title=title, xlabel=xlabel, ylabel=ylabel)
    
    # Handle different dimensionality of data
    if ndims(data) == 1
        lines!(ax, 1:length(data), data)
    elseif ndims(data) == 2
        heatmap!(ax, data)
        Colorbar(f[1, 2], colormap=:viridis)
    elseif ndims(data) == 3
        # Show first slice of 3D data
        heatmap!(ax, data[:, :, 1])
        Colorbar(f[1, 2], colormap=:viridis)
    end
    
    return f
end

function plot_variable(nc_data::NCData, variable::String)
    data = get_variable_data(nc_data, variable)
    return create_plot(data, variable)
end

function save_plot(figure, filename::String)
    save(filename, figure)
    return nothing
end

# Create a simple window and UI
win = GtkWindow("TRURL - NetCDF Viewer", 800, 600)

# Create a vertical box for layout
vbox = GtkBox(:v)
push!(win, vbox)

# Create toolbar
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 6)
set_gtk_property!(toolbar, :margin, 6)

# Create buttons
file_button = GtkButton("Open NetCDF")
var_label = GtkLabel("Variable:")
var_combo = GtkComboBoxText()
plot_button = GtkButton("Plot")
save_button = GtkButton("Save Plot")

# Add to toolbar
push!(toolbar, file_button)
push!(toolbar, var_label)
push!(toolbar, var_combo)
push!(toolbar, plot_button)
push!(toolbar, save_button)

# Create canvas
canvas = GtkCanvas()
set_gtk_property!(canvas, :expand, true)

# Create statusbar
statusbar = GtkStatusbar()
push!(statusbar, 0, "Ready to load NetCDF files")

# Add everything to main layout
push!(vbox, toolbar)
push!(vbox, canvas)
push!(vbox, statusbar)

# Variable to store NetCDF data
nc_data = nothing

# Signal handler functions
function on_file_open(w)
    global nc_data
    
    dialog = GtkFileChooserDialog("Open file", win, GtkFileChooserAction.OPEN,
                                 ("Cancel", GtkResponseType.CANCEL,
                                  "Open", GtkResponseType.ACCEPT))
    
    filter = GtkFileFilter()
    add_pattern(filter, "*.nc")
    add_pattern(filter, "*.nc4")
    add_pattern(filter, "*.netcdf")
    set_gtk_property!(dialog, :filter, filter)
    
    response = run(dialog)
    if response == GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        
        try
            nc_data = load_netcdf(filename)
            
            # Clear the combo box
            for i in length(var_combo)-1:-1:0
                splice!(var_combo, i)
            end
            
            # Add variables
            for var in nc_data.variables
                push!(var_combo, var)
            end
            
            # Select the first item
            if length(nc_data.variables) > 0
                set_gtk_property!(var_combo, :active, 0)
            end
            
            push!(statusbar, 0, "Loaded: $(basename(filename))")
        catch e
            error_dialog("Error loading file: $(e)")
            push!(statusbar, 0, "Error loading file")
        end
    else
        destroy(dialog)
    end
end

function error_dialog(message::String)
    dialog = GtkMessageDialog(win, GtkDialogFlags.MODAL, GtkMessageType.ERROR, 
                             GtkButtonsType.OK, message)
    response = run(dialog)
    destroy(dialog)
end

function on_plot(w)
    global nc_data
    
    if nc_data === nothing
        error_dialog("No data loaded")
        return
    end
    
    var = Gtk.active_text(var_combo)
    if var === nothing || length(var) == 0
        error_dialog("No variable selected")
        return
    end
    
    try
        figure = plot_variable(nc_data, var)
        
        @guarded draw(canvas) do c
            ctx = getgc(c)
            CairoMakie.activate!()
            screen = CairoMakie.Screen(ctx.surface)
            CairoMakie.draw(screen, figure)
        end
        
        Gtk.queue_draw(canvas)
        push!(statusbar, 0, "Plotted: $var")
    catch e
        error_dialog("Error plotting variable: $(e)")
        push!(statusbar, 0, "Error plotting variable")
    end
end

function on_save(w)
    dialog = GtkFileChooserDialog("Save plot", win, GtkFileChooserAction.SAVE,
                                 ("Cancel", GtkResponseType.CANCEL,
                                  "Save", GtkResponseType.ACCEPT))
    
    filter = GtkFileFilter()
    add_pattern(filter, "*.png")
    set_gtk_property!(dialog, :filter, filter)
    
    response = run(dialog)
    if response == GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        # Ensure the filename ends with .png
        if !endswith(lowercase(filename), ".png")
            filename = filename * ".png"
        end
        
        # Would implement saving the current plot
        push!(statusbar, 0, "Saved to: $(basename(filename))")
    else
        destroy(dialog)
    end
end

# Connect signals
signal_connect(on_file_open, file_button, "clicked")
signal_connect(on_plot, plot_button, "clicked")
signal_connect(on_save, save_button, "clicked")

# Show window
showall(win)

# Run the app
if !isinteractive()
    c = Condition()
    signal_connect(win, "destroy") do widget
        notify(c)
    end
    wait(c)
end