using Gtk
using NCDatasets

# Create window
win = GtkWindow("TRURL - Basic NetCDF Viewer", 600, 400)
vbox = GtkBox(:v)
push!(win, vbox)

# Add toolbar
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 5)
set_gtk_property!(toolbar, :margin, 5)
push!(vbox, toolbar)

# Add buttons
open_button = GtkButton("Open NetCDF")
push!(toolbar, open_button)

# Add variable selection
var_label = GtkLabel("Variable:")
push!(toolbar, var_label)

var_combo = GtkComboBoxText()
push!(toolbar, var_combo)

# Add text area to show variable data
scroll = GtkScrolledWindow()
set_gtk_property!(scroll, :hexpand, true)
set_gtk_property!(scroll, :vexpand, true)

buffer = GtkTextBuffer()
textview = GtkTextView(buffer)
set_gtk_property!(textview, :editable, false)
set_gtk_property!(textview, :cursor_visible, false)
set_gtk_property!(textview, :wrap_mode, 2)  # GTK_WRAP_WORD

push!(scroll, textview)
push!(vbox, scroll)

# Add status bar
statusbar = GtkStatusbar()
push!(vbox, statusbar)
ctx_id = push!(statusbar, 0, "Ready to load NetCDF files")

# Variable to store data
global nc_data = nothing
global nc_vars = String[]

# Function to load NetCDF file
function load_netcdf_file(filename)
    try
        ds = NCDataset(filename)
        global nc_vars = collect(keys(ds))
        
        # Update status
        push!(statusbar, 0, "Loaded: $(basename(filename)) with $(length(nc_vars)) variables")
        
        # Update combo box
        empty!(var_combo)
        for var in nc_vars
            push!(var_combo, var)
        end
        
        # Select first item
        if length(nc_vars) > 0
            set_gtk_property!(var_combo, :active, 0)
        end
        
        # Store the dataset
        global nc_data = ds
        
        return true
    catch e
        # Show error
        dialog = GtkMessageDialog(
            win, 
            Gtk.GConstants.GtkDialogFlags.MODAL, 
            Gtk.GConstants.GtkMessageType.ERROR,
            Gtk.GConstants.GtkButtonsType.OK,
            "Error loading NetCDF file: $(e)"
        )
        run(dialog)
        destroy(dialog)
        
        push!(statusbar, 0, "Error loading file")
        return false
    end
end

# Function to display variable data
function show_variable(var_name)
    if nc_data === nothing || !(var_name in nc_vars)
        return
    end
    
    try
        var_data = nc_data[var_name]
        dims = size(var_data)
        
        # Create text representation
        text = "Variable: $(var_name)\n"
        text *= "Dimensions: $(dims)\n"
        text *= "Type: $(typeof(var_data))\n\n"
        
        # Show a sample of the data
        text *= "Data sample:\n"
        
        if ndims(var_data) == 0
            text *= "$(var_data[:])"
        elseif ndims(var_data) == 1
            max_items = min(10, length(var_data))
            text *= "[" * join(["$(var_data[i])" for i in 1:max_items], ", ") * "]"
            if length(var_data) > max_items
                text *= "... ($(length(var_data) - max_items) more items)"
            end
        elseif ndims(var_data) == 2
            max_rows = min(5, size(var_data, 1))
            max_cols = min(5, size(var_data, 2))
            for i in 1:max_rows
                text *= "["
                for j in 1:max_cols
                    text *= "$(var_data[i, j]) "
                end
                if size(var_data, 2) > max_cols
                    text *= "... "
                end
                text *= "]\n"
            end
            if size(var_data, 1) > max_rows
                text *= "...\n"
            end
        else
            text *= "Data has $(ndims(var_data)) dimensions - showing dimensions only"
        end
        
        # Update text buffer
        set_gtk_property!(buffer, :text, text)
        
        push!(statusbar, 0, "Showing variable: $(var_name)")
    catch e
        set_gtk_property!(buffer, :text, "Error displaying variable: $(e)")
        push!(statusbar, 0, "Error displaying variable")
    end
end

# Connect signal for open button
signal_connect(open_button, "clicked") do widget
    dialog = GtkFileChooserDialog(
        "Open NetCDF file", win, 
        Gtk.GConstants.GtkFileChooserAction.OPEN
    )
    
    cancel_btn = GtkButton("Cancel")
    open_btn = GtkButton("Open")
    signal_connect(cancel_btn, "clicked") do widget
        Gtk.response(dialog, Gtk.GConstants.GtkResponseType.CANCEL)
    end
    signal_connect(open_btn, "clicked") do widget
        Gtk.response(dialog, Gtk.GConstants.GtkResponseType.ACCEPT)
    end
    
    cancel_btn_id = push!(dialog, cancel_btn)
    open_btn_id = push!(dialog, open_btn)
    
    filter = GtkFileFilter()
    add_pattern(filter, "*.nc")
    add_pattern(filter, "*.nc4")
    add_pattern(filter, "*.netcdf")
    set_gtk_property!(dialog, :filter, filter)
    
    response = run(dialog)
    
    if response == Gtk.GConstants.GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        load_netcdf_file(filename)
    else
        destroy(dialog)
    end
end

# Connect signal for variable selection
signal_connect(var_combo, "changed") do widget
    var = Gtk.active_text(var_combo)
    if var !== nothing && length(var) > 0
        show_variable(var)
    end
end

# Connect signal for window close
signal_connect(win, "destroy") do widget
    # Close the NetCDF dataset if open
    if nc_data !== nothing
        try
            close(nc_data)
        catch
            # Ignore errors on closing
        end
    end
    
    Gtk.gtk_quit()
end

# Show all widgets
showall(win)

# Start GTK main loop
if !isinteractive()
    Gtk.gtk_main()
end