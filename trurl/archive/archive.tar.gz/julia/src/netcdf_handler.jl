struct NCData
    filename::String
    variables::Vector{String}
    dimensions::Dict{String, Int}
    data::Dict{String, Array}
end

function load_netcdf(filename::String)
    ds = NCDataset(filename)
    variables = keys(ds) |> collect
    dimensions = Dict{String, Int}()
    data = Dict{String, Array}()
    
    for dim in keys(ds.dim)
        dimensions[dim] = ds.dim[dim]
    end
    
    for var in variables
        data[var] = ds[var][:]
    end
    
    close(ds)
    return NCData(filename, variables, dimensions, data)
end

function get_variable_data(nc_data::NCData, variable::String)
    return nc_data.data[variable]
end

function get_variable_dimensions(nc_data::NCData, variable::String)
    return size(nc_data.data[variable])
end