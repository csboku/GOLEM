using Gtk
using NCDatasets

# Create window with better title
win = GtkWindow("TRURL - NetCDF Explorer", 800, 600)
set_gtk_property!(win, :border_width, 10)

# Create main vertical layout
main_vbox = GtkBox(:v)
set_gtk_property!(main_vbox, :spacing, 10)
push!(win, main_vbox)

# Create toolbar
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 8)
push!(main_vbox, toolbar)

# Add open button
open_btn = GtkButton("Open NetCDF File")
push!(toolbar, open_btn)

# Add file label
file_label = GtkLabel("No file loaded")
set_gtk_property!(file_label, :ellipsize, 3) # PANGO_ELLIPSIZE_END
set_gtk_property!(file_label, :hexpand, true)
set_gtk_property!(file_label, :halign, 0) # GTK_ALIGN_FILL
push!(toolbar, file_label)

# Create horizontal paned layout for side-by-side view
paned = GtkPaned(:h)
set_gtk_property!(paned, :position, 250)
set_gtk_property!(paned, :expand, true)
push!(main_vbox, paned)

# Create left panel for variable selection
left_vbox = GtkBox(:v)
set_gtk_property!(left_vbox, :spacing, 5)
push!(paned, left_vbox)

# Add variable list frame
var_frame = GtkFrame("Variables")
set_gtk_property!(var_frame, :expand, true)
set_gtk_property!(var_frame, :shadow_type, 0) # GTK_SHADOW_NONE
push!(left_vbox, var_frame)

# Create scrollable list for variables
var_sw = GtkScrolledWindow()
push!(var_frame, var_sw)

# Create list store and view
var_store = GtkListStore(String)
var_view = GtkTreeView(GtkTreeModel(var_store))
var_renderer = GtkCellRendererText()
var_column = GtkTreeViewColumn("Name", var_renderer, Dict([("text", 0)]))
push!(var_view, var_column)
push!(var_sw, var_view)

# Create right panel for content
right_vbox = GtkBox(:v)
set_gtk_property!(right_vbox, :spacing, 10)
push!(paned, right_vbox)

# Add dimensions frame
dim_frame = GtkFrame("Dimensions")
set_gtk_property!(dim_frame, :shadow_type, 0) # GTK_SHADOW_NONE
push!(right_vbox, dim_frame)

# Add scrolled window for dimensions
dim_sw = GtkScrolledWindow()
set_gtk_property!(dim_sw, :min_content_height, 100)
push!(dim_frame, dim_sw)

# Add text view for dimensions
dim_buffer = GtkTextBuffer()
dim_view = GtkTextView(dim_buffer)
set_gtk_property!(dim_view, :editable, false)
set_gtk_property!(dim_view, :cursor_visible, false)
push!(dim_sw, dim_view)

# Add variable info frame
var_info_frame = GtkFrame("Variable Information")
set_gtk_property!(var_info_frame, :shadow_type, 0) # GTK_SHADOW_NONE
set_gtk_property!(var_info_frame, :expand, true)
push!(right_vbox, var_info_frame)

# Add scrolled window for variable info
var_info_sw = GtkScrolledWindow()
push!(var_info_frame, var_info_sw)

# Add text view for variable info
var_info_buffer = GtkTextBuffer()
var_info_view = GtkTextView(var_info_buffer)
set_gtk_property!(var_info_view, :editable, false)
set_gtk_property!(var_info_view, :cursor_visible, false)
set_gtk_property!(var_info_view, :wrap_mode, 2) # GTK_WRAP_WORD
push!(var_info_sw, var_info_view)

# Add status bar
status_label = GtkLabel("Ready")
set_gtk_property!(status_label, :halign, 0) # GTK_ALIGN_FILL
push!(main_vbox, status_label)

# Global variables
global current_dataset = nothing
global current_filepath = nothing

# Function to load NetCDF file
function load_netcdf(filepath)
    try
        # Close previous dataset if open
        if current_dataset !== nothing && isopen(current_dataset)
            close(current_dataset)
        end
        
        # Open new dataset
        ds = NCDataset(filepath)
        global current_dataset = ds
        global current_filepath = filepath
        
        # Update file label
        set_gtk_property!(file_label, :label, "File: $(basename(filepath))")
        
        # Clear variable list
        empty!(var_store)
        
        # Add variables to list
        for var_name in sort(collect(keys(ds)))
            push!(var_store, (var_name,))
        end
        
        # Update dimensions view
        dim_text = "File dimensions:\n"
        for (name, len) in ds.dim
            dim_text *= "• $name: $len\n"
        end
        set_gtk_property!(dim_buffer, :text, dim_text)
        
        # Show global attributes if any
        if length(keys(ds.attrib)) > 0
            var_info_text = "Global Attributes:\n"
            for (name, val) in sort(collect(ds.attrib))
                var_info_text *= "• $name: $val\n"
            end
            set_gtk_property!(var_info_buffer, :text, var_info_text)
        else
            set_gtk_property!(var_info_buffer, :text, "Select a variable to view its information")
        end
        
        # Update status
        set_gtk_property!(status_label, :label, "Loaded $(length(keys(ds))) variables, $(length(keys(ds.dim))) dimensions")
        
        return true
    catch e
        set_gtk_property!(status_label, :label, "Error: $(string(e))")
        return false
    end
end

# Function to display variable information
function show_variable_info(var_name)
    if current_dataset === nothing || !haskey(current_dataset, var_name)
        return
    end
    
    try
        # Get variable
        var = current_dataset[var_name]
        
        # Create info text
        info_text = "Variable: $var_name\n\n"
        
        # Add basic info
        info_text *= "Type: $(eltype(var))\n"
        info_text *= "Dimensions: $(join(size(var), " × "))\n"
        
        # Show dimension info if available
        dims = []
        try
            dims = dimnames(var)
            if length(dims) > 0
                info_text *= "Dimension names: $(join(dims, ", "))\n"
            end
        catch
            # Ignore if dimension names not available
        end
        
        # Add attributes
        if length(keys(var.attrib)) > 0
            info_text *= "\nAttributes:\n"
            for (name, val) in sort(collect(var.attrib))
                info_text *= "• $name: $val\n"
            end
        end
        
        # Try to show data sample
        info_text *= "\nData Sample:\n"
        try
            if ndims(var) == 0
                # Scalar
                info_text *= "$(var[:])"
            elseif ndims(var) == 1
                # 1D array
                max_show = min(length(var), 10)
                sample = var[1:max_show]
                info_text *= "[$(join(sample, ", "))]"
                if length(var) > max_show
                    info_text *= " ... ($(length(var) - max_show) more elements)"
                end
            elseif ndims(var) == 2
                # 2D array
                rows = min(size(var, 1), 5)
                cols = min(size(var, 2), 5)
                for i in 1:rows
                    row_vals = []
                    for j in 1:cols
                        push!(row_vals, "$(var[i, j])")
                    end
                    info_text *= "[$(join(row_vals, ", "))]"
                    if size(var, 2) > cols
                        info_text *= " ..."
                    end
                    info_text *= "\n"
                end
                if size(var, 1) > rows
                    info_text *= "...\n"
                end
            else
                # Higher dimensions
                info_text *= "($(ndims(var))D array, too large to display)"
            end
        catch e
            info_text *= "(Error displaying data: $e)"
        end
        
        # Update info view
        set_gtk_property!(var_info_buffer, :text, info_text)
        
        # Update status
        set_gtk_property!(status_label, :label, "Viewing: $var_name")
        
        return true
    catch e
        set_gtk_property!(var_info_buffer, :text, "Error: $e")
        set_gtk_property!(status_label, :label, "Error displaying variable")
        return false
    end
end

# Connect variable selection signal
selection = GAccessor.selection(var_view)
signal_connect(selection, "changed") do widget
    selected_path = selected(selection)
    if selected_path !== nothing
        iter = Gtk.iter_from_index(var_store, selected_path)
        var_name = Gtk.get_string(var_store, iter, 1)
        show_variable_info(var_name)
    end
end

# Connect open button signal
signal_connect(open_btn, "clicked") do widget
    # Use native file dialog
    filepath = open_dialog("Open NetCDF File", win, ("*.nc", "*.nc4", "*.netcdf"))
    if filepath !== nothing
        load_netcdf(filepath)
    end
end

# Connect window destroy signal to clean up
signal_connect(win, "destroy") do widget
    if current_dataset !== nothing && isopen(current_dataset)
        close(current_dataset)
    end
end

# Show all widgets
showall(win)

# Run the main loop
if !isinteractive()
    @async while true
        sleep(0.1)
        Gtk.gtk_main_iteration(true)
    end
    Gtk.waitforsignal(win, :destroy)
end