using Gtk
using NCDatasets

# Create window
win = GtkWindow("Ultra Minimal NetCDF Viewer", 400, 300)

# Create layout
box = GtkBox(:v)
push!(win, box)

# Add button
button = GtkButton("Open NetCDF File")
push!(box, button)

# Add info label
info = GtkLabel("No file loaded")
push!(box, info)

# Connect button click
signal_connect(button, "clicked") do widget
    # Show file selection dialog  
    path = open_dialog("Select NetCDF file", win)
    
    # If a file was selected
    if path !== nothing
        try
            # Load the file
            ds = NCDataset(path)
            
            # Get basic info
            var_count = length(keys(ds))
            
            # Update label
            set_gtk_property!(info, :label, "Loaded: $(basename(path))\n$var_count variables found")
            
            # Close dataset
            close(ds)
        catch e
            # Show error
            set_gtk_property!(info, :label, "Error: $e")
        end
    end
end

# Show all widgets
showall(win)

# Run main loop
if !isinteractive()
    @async Gtk.gtk_main()
    Gtk.waitforsignal(win, :destroy)
end