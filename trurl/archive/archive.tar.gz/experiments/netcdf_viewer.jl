using Gtk
using NCDatasets
using CairoMakie
using Printf

# Global variables
global current_dataset = nothing
global current_figure = nothing

# Create the main window
win = GtkWindow("TRURL - NetCDF Viewer", 800, 600)

# Create the main vertical layout
main_box = GtkBox(:v)
push!(win, main_box)

# Create the toolbar
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 10)
set_gtk_property!(toolbar, :margin, 10)
push!(main_box, toolbar)

# Add toolbar widgets
open_button = GtkButton("Open NetCDF")
push!(toolbar, open_button)

var_label = GtkLabel("Variable:")
push!(toolbar, var_label)

var_combo = GtkComboBoxText()
push!(toolbar, var_combo)

plot_button = GtkButton("Plot")
push!(toolbar, plot_button)

save_button = GtkButton("Save Plot")
push!(toolbar, save_button)

# Create the content area (split view)
content_box = GtkBox(:h)
set_gtk_property!(content_box, :expand, true)
push!(main_box, content_box)

# Create the left sidebar for variable details
sidebar = GtkBox(:v)
set_gtk_property!(sidebar, :width_request, 250)
push!(content_box, sidebar)

# Add variable info view
info_frame = GtkFrame("Variable Info")
set_gtk_property!(info_frame, :shadow_type, Gtk.GConstants.GtkShadowType.ETCHED_IN)
set_gtk_property!(info_frame, :margin, 5)
push!(sidebar, info_frame)

info_sw = GtkScrolledWindow()
set_gtk_property!(info_sw, :min_content_height, 200)
push!(info_frame, info_sw)

info_buffer = GtkTextBuffer()
info_view = GtkTextView(info_buffer)
set_gtk_property!(info_view, :editable, false)
set_gtk_property!(info_view, :cursor_visible, false)
set_gtk_property!(info_view, :wrap_mode, Gtk.GConstants.GtkWrapMode.WORD)
push!(info_sw, info_view)

# Add metadata view
meta_frame = GtkFrame("File Metadata")
set_gtk_property!(meta_frame, :shadow_type, Gtk.GConstants.GtkShadowType.ETCHED_IN)
set_gtk_property!(meta_frame, :margin, 5)
set_gtk_property!(meta_frame, :expand, true)
push!(sidebar, meta_frame)

meta_sw = GtkScrolledWindow()
push!(meta_frame, meta_sw)

meta_buffer = GtkTextBuffer()
meta_view = GtkTextView(meta_buffer)
set_gtk_property!(meta_view, :editable, false)
set_gtk_property!(meta_view, :cursor_visible, false)
set_gtk_property!(meta_view, :wrap_mode, Gtk.GConstants.GtkWrapMode.WORD)
push!(meta_sw, meta_view)

# Create the plot area
plot_box = GtkBox(:v)
set_gtk_property!(plot_box, :expand, true)
push!(content_box, plot_box)

canvas = GtkCanvas()
set_gtk_property!(canvas, :expand, true)
push!(plot_box, canvas)

# Add status bar
statusbar = GtkStatusbar()
ctx_id = push!(statusbar, 0, "Ready to load NetCDF files")
push!(main_box, statusbar)

# Function to load NetCDF file
function load_netcdf_file(filename)
    try
        # Close previous dataset if open
        if current_dataset !== nothing
            close(current_dataset)
        end
        
        # Open the NetCDF file
        ds = NCDataset(filename)
        global current_dataset = ds
        
        # Update the status bar
        push!(statusbar, 0, "Loaded: $(basename(filename))")
        
        # Clear the variable combo
        empty!(var_combo)
        
        # Add variables to combo box
        for var_name in keys(ds)
            # Skip dimension variables for simplicity
            if !(var_name in keys(ds.dim))
                push!(var_combo, var_name)
            end
        end
        
        # Select first variable if available
        if length(var_combo) > 0
            set_gtk_property!(var_combo, :active, 0)
            update_var_info(Gtk.active_text(var_combo))
        end
        
        # Update metadata information
        update_metadata(ds)
        
        return true
    catch e
        error_dialog("Error loading NetCDF file: $e")
        push!(statusbar, 0, "Error loading file")
        return false
    end
end

# Function to update variable information
function update_var_info(var_name)
    if current_dataset === nothing || var_name === nothing
        return
    end
    
    try
        var = current_dataset[var_name]
        
        # Build information string
        info = "Variable: $(var_name)\n"
        info *= "Dimensions: $(join(size(var), " × "))\n"
        info *= "Type: $(eltype(var))\n"
        
        # Add attributes if any
        if length(keys(var.attrib)) > 0
            info *= "\nAttributes:\n"
            for (key, val) in var.attrib
                info *= "  $key: $val\n"
            end
        end
        
        # Add data ranges
        if length(var) > 0
            info *= "\nData Range:\n"
            info *= "  Min: $(minimum(skipmissing(var[:])))\n"
            info *= "  Max: $(maximum(skipmissing(var[:])))\n"
        end
        
        # Update the info view
        set_gtk_property!(info_buffer, :text, info)
    catch e
        set_gtk_property!(info_buffer, :text, "Error getting variable info: $e")
    end
end

# Function to update metadata information
function update_metadata(ds)
    if ds === nothing
        return
    end
    
    try
        meta = "Dimensions:\n"
        for (dim_name, dim_len) in ds.dim
            meta *= "  $dim_name: $dim_len\n"
        end
        
        meta *= "\nGlobal Attributes:\n"
        for (key, val) in ds.attrib
            meta *= "  $key: $val\n"
        end
        
        # Update the metadata view
        set_gtk_property!(meta_buffer, :text, meta)
    catch e
        set_gtk_property!(meta_buffer, :text, "Error getting metadata: $e")
    end
end

# Function to create a plot
function create_plot(var_name)
    if current_dataset === nothing || var_name === nothing
        return false
    end
    
    try
        var = current_dataset[var_name]
        data = var[:]
        
        # Create figure
        fig = Figure(resolution=(600, 400))
        
        # Check if the data can be plotted
        if eltype(data) <: Union{Missing, Number} || eltype(data) <: Number
            # Different plot types based on dimensions
            if ndims(data) == 1
                # 1D data: line plot
                ax = Axis(fig[1, 1], 
                        title=var_name,
                        xlabel="Index",
                        ylabel=get(var.attrib, "units", ""))
                lines!(ax, 1:length(data), Array{Float64}(replace(data, missing => NaN)))
                
            elseif ndims(data) == 2
                # 2D data: heatmap
                ax = Axis(fig[1, 1], 
                        title=var_name,
                        xlabel="X",
                        ylabel="Y")
                hm = heatmap!(ax, Array{Float64}(replace(data, missing => NaN)))
                Colorbar(fig[1, 2], hm)
                
            elseif ndims(data) == 3
                # 3D data: show first slice as heatmap
                ax = Axis(fig[1, 1], 
                        title="$(var_name) (First slice)",
                        xlabel="X",
                        ylabel="Y")
                slice = data[:, :, 1]
                hm = heatmap!(ax, Array{Float64}(replace(slice, missing => NaN)))
                Colorbar(fig[1, 2], hm)
                
            else
                error_dialog("Cannot plot data with $(ndims(data)) dimensions")
                return false
            end
        else
            error_dialog("Cannot plot data of type $(eltype(data))")
            return false
        end
        
        # Store the figure
        global current_figure = fig
        
        # Draw to canvas
        @guarded draw(canvas) do c
            ctx = getgc(c)
            CairoMakie.activate!()
            screen = CairoMakie.Screen(ctx.surface)
            CairoMakie.draw(screen, fig)
        end
        
        # Redraw canvas
        Gtk.queue_draw(canvas)
        
        # Update status
        push!(statusbar, 0, "Plotted: $var_name")
        
        return true
    catch e
        error_dialog("Error creating plot: $e")
        push!(statusbar, 0, "Error plotting")
        return false
    end
end

# Function to save the current plot
function save_plot()
    if current_figure === nothing
        error_dialog("No plot to save")
        return false
    end
    
    # Show save dialog
    path = save_dialog("Save Plot", win, ("*.png", "*.pdf"))
    
    if path !== nothing
        try
            # Add extension if needed
            if !endswith(lowercase(path), ".png") && !endswith(lowercase(path), ".pdf")
                path *= ".png"
            end
            
            # Save the figure
            save(path, current_figure)
            
            # Update status
            push!(statusbar, 0, "Saved plot to: $(basename(path))")
            
            return true
        catch e
            error_dialog("Error saving plot: $e")
            push!(statusbar, 0, "Error saving plot")
            return false
        end
    end
    
    return false
end

# Helper function for showing error dialogs
function error_dialog(message)
    dialog = GtkMessageDialog(
        win, 
        Gtk.GConstants.GtkDialogFlags.MODAL,
        Gtk.GConstants.GtkMessageType.ERROR,
        Gtk.GConstants.GtkButtonsType.OK,
        message
    )
    response = run(dialog)
    destroy(dialog)
end

# Connect signals
signal_connect(open_button, "clicked") do widget
    path = open_dialog("Open NetCDF File", win, ("*.nc", "*.nc4", "*.netcdf"))
    if path !== nothing
        load_netcdf_file(path)
    end
end

signal_connect(var_combo, "changed") do widget
    var_name = Gtk.active_text(var_combo)
    if var_name !== nothing
        update_var_info(var_name)
    end
end

signal_connect(plot_button, "clicked") do widget
    var_name = Gtk.active_text(var_combo)
    if var_name !== nothing
        create_plot(var_name)
    else
        error_dialog("No variable selected")
    end
end

signal_connect(save_button, "clicked") do widget
    save_plot()
end

signal_connect(win, "destroy") do widget
    # Clean up resources
    if current_dataset !== nothing
        try
            close(current_dataset)
        catch
            # Ignore errors on close
        end
    end
end

# Show window and start the main loop
showall(win)

if !isinteractive()
    # Start the GTK main loop asynchronously
    @async while true
        sleep(0.1)
        Gtk.gtk_main_iteration_do(false)
    end
    
    # Create a condition to wait on
    c = Condition()
    
    # Add an additional signal handler for window destroy to notify condition
    signal_connect(win, "destroy") do widget
        notify(c)
    end
    
    # Wait until window is closed
    wait(c)
end