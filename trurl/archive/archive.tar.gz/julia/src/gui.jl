mutable struct TrurlApp
    window::GtkWindow
    file_button::GtkButton
    variable_combo::GtkComboBoxText
    plot_button::GtkButton
    save_button::GtkButton
    canvas::GtkCanvas
    status_bar::GtkStatusbar
    nc_data::Union{NCData, Nothing}
    
    function TrurlApp()
        builder = GtkBuilder(filename=joinpath(@__DIR__, "..", "ui", "main.ui"))
        
        window = builder["window1"]
        file_button = builder["file_button"]
        variable_combo = builder["variable_combo"]
        plot_button = builder["plot_button"]
        save_button = builder["save_button"]
        canvas = GtkCanvas()
        status_bar = builder["status_bar"]
        
        # Replace the placeholder canvas with our GtkCanvas
        canvas_box = builder["canvas_box"]
        push!(canvas_box, canvas)
        set_gtk_property!(canvas, :expand, true)
        set_gtk_property!(canvas, :visible, true)
        
        # Initialize the status bar with a welcome message
        push!(status_bar, 0, "Ready to load NetCDF files")
        
        app = new(window, file_button, variable_combo, plot_button, save_button, canvas, status_bar, nothing)
        connect_signals(app)
        
        return app
    end
end

function run(app::TrurlApp)
    showall(app.window)
    
    # Create a condition to wait on
    c = Condition()
    
    # Connect the destroy signal to notify the condition
    signal_connect(app.window, "destroy") do _
        notify(c)
    end
    
    # Wait until the window is closed
    wait(c)
end

function connect_signals(app::TrurlApp)
    signal_connect(app.file_button, "clicked") do _
        open_file_dialog(app)
    end
    
    signal_connect(app.plot_button, "clicked") do _
        plot_selected_variable(app)
    end
    
    signal_connect(app.save_button, "clicked") do _
        save_plot_dialog(app)
    end
    
    # Window destroy is handled in the run function
end

function open_file_dialog(app::TrurlApp)
    dialog = GtkFileChooserDialog("Open file", app.window, GtkFileChooserAction.OPEN,
                                  (("Cancel", GtkResponseType.CANCEL),
                                   ("Open", GtkResponseType.ACCEPT)))
    
    filter = GtkFileFilter()
    add_pattern(filter, "*.nc")
    add_pattern(filter, "*.nc4")
    add_pattern(filter, "*.netcdf")
    set_gtk_property!(dialog, :filter, filter)
    
    response = run(dialog)
    if response == GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        load_file(app, filename)
    else
        destroy(dialog)
    end
end

function load_file(app::TrurlApp, filename::String)
    try
        app.nc_data = load_netcdf(filename)
        update_variable_list(app)
        push!(app.status_bar, 0, "Loaded: $(basename(filename))")
    catch e
        error_dialog("Error loading file: $(e)")
        push!(app.status_bar, 0, "Error loading file")
    end
end

function update_variable_list(app::TrurlApp)
    if app.nc_data === nothing
        return
    end
    
    # Clear the combo box
    for i in length(app.variable_combo)-1:-1:0
        splice!(app.variable_combo, i)
    end
    
    # Add variables
    for var in app.nc_data.variables
        push!(app.variable_combo, var)
    end
    
    # Select the first item
    if length(app.nc_data.variables) > 0
        set_gtk_property!(app.variable_combo, :active, 0)
    end
end

function plot_selected_variable(app::TrurlApp)
    if app.nc_data === nothing
        error_dialog("No data loaded")
        return
    end
    
    var = Gtk.active_text(app.variable_combo)
    if var === nothing || length(var) == 0
        error_dialog("No variable selected")
        return
    end
    
    try
        figure = plot_variable(app.nc_data, var)
        
        @guarded draw(app.canvas) do canvas
            ctx = getgc(canvas)
            CairoMakie.activate!()
            screen = CairoMakie.Screen(ctx.surface)
            CairoMakie.draw(screen, figure)
        end
        
        Gtk.queue_draw(app.canvas)
        push!(app.status_bar, 0, "Plotted: $var")
    catch e
        error_dialog("Error plotting variable: $(e)")
        push!(app.status_bar, 0, "Error plotting variable")
    end
end

function save_plot_dialog(app::TrurlApp)
    dialog = GtkFileChooserDialog("Save plot", app.window, GtkFileChooserAction.SAVE,
                                 (("Cancel", GtkResponseType.CANCEL),
                                  ("Save", GtkResponseType.ACCEPT)))
    
    filter = GtkFileFilter()
    add_pattern(filter, "*.png")
    set_gtk_property!(dialog, :filter, filter)
    
    response = run(dialog)
    if response == GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        # Ensure the filename ends with .png
        if !endswith(lowercase(filename), ".png")
            filename = filename * ".png"
        end
        
        # Need to implement saving the current plot
        # This would typically create a new figure and save it
        push!(app.status_bar, 0, "Saved to: $(basename(filename))")
    else
        destroy(dialog)
    end
end

function error_dialog(message::String)
    dialog = GtkMessageDialog(nothing, GtkDialogFlags.MODAL, GtkMessageType.ERROR, 
                             GtkButtonsType.OK, message)
    response = run(dialog)
    destroy(dialog)
end;