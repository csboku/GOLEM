using Gtk
using NCDatasets

# Track active dataset
global nc_file = nothing

# Create main window
win = GtkWindow("TRURL - Minimal NetCDF Viewer", 600, 400)

# Create main vertical layout
vbox = GtkBox(:v)
push!(win, vbox)

# Create toolbar
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 5)
push!(vbox, toolbar)

# Add a button to open files
open_button = GtkButton("Open NetCDF File")
push!(toolbar, open_button)

# Add a label for status
status_label = GtkLabel("No file loaded")
push!(toolbar, status_label)

# Create text view for displaying data
sw = GtkScrolledWindow()
push!(vbox, sw)

# Create text view buffer and view
buffer = GtkTextBuffer()
tv = GtkTextView(buffer)
push!(sw, tv)

# Function to load and display NetCDF summary
function load_netcdf_file(filename)
    try
        # Open NetCDF file
        ds = NCDataset(filename)
        
        # Update status
        set_gtk_property!(status_label, :label, "Loaded: $(basename(filename))")
        
        # Store the dataset
        global nc_file = ds
        
        # Build summary text
        text = "NetCDF File: $(basename(filename))\n\n"
        text *= "Variables:\n"
        
        # List variables
        for (name, var) in ds
            dims = join(size(var), "×")
            text *= "  $name: $dims $(typeof(var))\n"
        end
        
        # Update text view
        set_gtk_property!(buffer, :text, text)
        
        return true
    catch e
        # Show error
        println("Error: $e")
        set_gtk_property!(status_label, :label, "Error loading file")
        set_gtk_property!(buffer, :text, "Error loading file: $e")
        return false
    end
end

# Connect open button to file chooser dialog
signal_connect(open_button, "clicked") do widget
    # Show file open dialog
    filename = open_dialog("Open NetCDF file", win, ("*.nc", "*.nc4", "*.netcdf"))
    
    if filename !== nothing
        load_netcdf_file(filename)
    end
end

# Connect window destroy signal
signal_connect(win, "destroy") do widget
    global nc_file
    if nc_file !== nothing
        try
            close(nc_file)
        catch
            # Ignore errors on close
        end
    end
    Gtk.quit()
end

# Show window
showall(win)

# Start main loop
if !isinteractive()
    Gtk.main()
end