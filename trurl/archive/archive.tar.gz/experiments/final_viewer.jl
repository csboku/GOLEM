using Gtk
using NCDatasets
using Printf

# Global variables to store state
global loaded_file = nothing

# Create the main window
win = GtkWindow("TRURL - Simple NetCDF Viewer", 600, 500)
set_gtk_property!(win, :border_width, 10)

# Create vertical box for main layout
vbox = GtkBox(:v)
set_gtk_property!(vbox, :spacing, 10)
push!(win, vbox)

# Create a toolbar with open button
toolbar = GtkBox(:h)
set_gtk_property!(toolbar, :spacing, 5)
push!(vbox, toolbar)

open_btn = GtkButton("Open NetCDF File")
push!(toolbar, open_btn)

# Create file info label
file_label = GtkLabel("No file loaded")
set_gtk_property!(file_label, :halign, Gtk.GConstants.GtkAlign.START)
push!(vbox, file_label)

# Create scrollable text view for displaying variable information
scrolled_window = GtkScrolledWindow()
set_gtk_property!(scrolled_window, :hexpand, true)
set_gtk_property!(scrolled_window, :vexpand, true)
push!(vbox, scrolled_window)

buffer = GtkTextBuffer()
textview = GtkTextView(buffer)
set_gtk_property!(textview, :editable, false)
set_gtk_property!(textview, :wrap_mode, Gtk.GConstants.GtkWrapMode.WORD)
push!(scrolled_window, textview)

# Function to extract and display NetCDF information
function display_netcdf_info(filename)
    try
        # Clean up previous file if open
        if loaded_file !== nothing && isopen(loaded_file)
            close(loaded_file)
        end
        
        # Open the NetCDF file
        ds = NCDataset(filename)
        global loaded_file = ds
        
        # Update file label
        set_gtk_property!(file_label, :label, "File: $(basename(filename))")
        
        # Generate text with file information
        text = "# NetCDF File: $(basename(filename))\n\n"
        
        # Add dimensions information
        text *= "## Dimensions\n"
        for (name, len) in ds.dim
            text *= "* $name: $len\n"
        end
        text *= "\n"
        
        # Add variables information
        text *= "## Variables\n"
        for name in keys(ds)
            var = ds[name]
            dims = join(size(var), " × ")
            var_type = eltype(var)
            
            text *= "### $name\n"
            text *= "* Type: $var_type\n"
            text *= "* Dimensions: $dims\n"
            
            # Add attributes
            if length(keys(var.attrib)) > 0
                text *= "* Attributes:\n"
                for (attr_name, attr_val) in var.attrib
                    text *= "  - $attr_name: $attr_val\n"
                end
            end
            
            # Add data sample
            text *= "* Data sample: "
            try
                if length(var) <= 10
                    text *= "$(var[:])\n"
                else
                    if ndims(var) == 1
                        text *= "[$(join(var[1:min(5, end)], ", ")), ...]\n"
                    elseif ndims(var) == 2 && size(var, 1) <= 3 && size(var, 2) <= 3
                        text *= "$(var[:,:])\n"
                    else
                        text *= "(data too large to display)\n"
                    end
                end
            catch
                text *= "(unable to display data)\n"
            end
            
            text *= "\n"
        end
        
        # Add global attributes
        if length(keys(ds.attrib)) > 0
            text *= "## Global Attributes\n"
            for (name, val) in ds.attrib
                text *= "* $name: $val\n"
            end
        end
        
        # Update text view
        set_gtk_property!(buffer, :text, text)
        
        return true
    catch e
        # Show error in text view
        set_gtk_property!(buffer, :text, "Error loading file: $e")
        set_gtk_property!(file_label, :label, "Error loading file")
        
        return false
    end
end

# Connect the open button click handler
signal_connect(open_btn, "clicked") do widget
    # Create file chooser dialog
    dialog = GtkFileChooserDialog(
        "Open NetCDF File", 
        win,
        Gtk.GConstants.GtkFileChooserAction.OPEN
    )
    
    # Add buttons to the dialog
    push!(dialog, "Cancel", Gtk.GConstants.GtkResponseType.CANCEL)
    push!(dialog, "Open", Gtk.GConstants.GtkResponseType.ACCEPT)
    
    # Add file filter for NetCDF files
    filter = GtkFileFilter()
    add_pattern(filter, "*.nc")
    add_pattern(filter, "*.nc4")
    add_pattern(filter, "*.netcdf")
    set_gtk_property!(dialog, :filter, filter)
    
    # Show the dialog and wait for user response
    response = run(dialog)
    
    if response == Gtk.GConstants.GtkResponseType.ACCEPT
        filename = Gtk.filename(dialog)
        destroy(dialog)
        display_netcdf_info(filename)
    else
        destroy(dialog)
    end
end

# Connect window destroy handler to clean up resources
signal_connect(win, "destroy") do widget
    if loaded_file !== nothing && isopen(loaded_file)
        close(loaded_file)
    end
end

# Show the window
showall(win)

# Start the GTK main loop
if !isinteractive()
    Gtk.gtk_main()
end