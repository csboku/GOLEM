using Gtk
using NCDatasets

# Create window
win = GtkWindow("TRURL - Simplest NetCDF Viewer", 500, 400)
vbox = GtkBox(:v)
push!(win, vbox)

# Add a text view
scrolled = GtkScrolledWindow()
set_gtk_property!(scrolled, :vexpand, true)
push!(vbox, scrolled)

buffer = GtkTextBuffer()
textview = GtkTextView(buffer)
set_gtk_property!(textview, :editable, false)
push!(scrolled, textview)

# Set some initial text
set_gtk_property!(buffer, :text, "Click 'Open File' to load a NetCDF file")

# Add a button
button = GtkButton("Open File")
push!(vbox, button)

# Connect to button click
signal_connect(button, "clicked") do widget
    # Use simple native file dialog
    filename = open_dialog("Select a NetCDF file", GtkNullContainer(), ("*.nc", "*.nc4"))
    
    if filename !== nothing
        try
            # Load the file
            ds = NCDataset(filename)
            
            # Build text content
            text = "File: $(filename)\n\n"
            
            # Add dimensions
            text *= "Dimensions:\n"
            for (dim, len) in ds.dim
                text *= "- $dim: $len\n"
            end
            
            # Add variables
            text *= "\nVariables:\n"
            for var_name in keys(ds)
                var = ds[var_name]
                text *= "- $var_name: $(size(var)) $(eltype(var))\n"
                
                # Add a few attributes if any
                if length(keys(var.attrib)) > 0
                    for (att, val) in var.attrib
                        text *= "  • $att: $val\n"
                    end
                end
            end
            
            # Add global attributes
            if length(keys(ds.attrib)) > 0
                text *= "\nGlobal Attributes:\n"
                for (att, val) in ds.attrib
                    text *= "- $att: $val\n"
                end
            end
            
            # Update the text view
            set_gtk_property!(buffer, :text, text)
            
            # Close the dataset
            close(ds)
        catch e
            # Show error
            set_gtk_property!(buffer, :text, "Error loading file: $e")
        end
    end
end

# Show the window
showall(win)

# Start main loop
if !isinteractive()
    @async while true
        sleep(0.1)
        Gtk.gtk_main_iteration(true)
    end
    Gtk.waitforsignal(win, :destroy)
end