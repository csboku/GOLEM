#!/bin/bash
# Run script for TRURL

# Make sure we're in the project directory
cd "$(dirname "$0")"

# Display startup message
echo "TRURL NetCDF Viewer"
echo "=================="
echo "1: Simple GTK test"
echo "2: Simplest NetCDF viewer"
echo "3: Enhanced NetCDF Explorer (recommended)"
echo "4: Ultra minimal NetCDF viewer"
echo ""

read -p "Which version would you like to run? (1-4): " choice

case $choice in
    1)
        echo "Running simple GTK test..."
        julia --project -e 'using Pkg; Pkg.add("Dates"); Pkg.add("Gtk")' > /dev/null 2>&1
        julia --project simple.jl
        ;;
    
    2)
        echo "Installing NCDatasets package..."
        julia --project -e 'using Pkg; Pkg.add("NCDatasets")' > /dev/null 2>&1
        
        echo "Running simplest NetCDF viewer..."
        julia --project simplest_viewer.jl
        ;;
    
    3)
        echo "Installing required packages..."
        julia --project -e 'using Pkg; Pkg.add("NCDatasets")' > /dev/null 2>&1
        
        echo "Running enhanced NetCDF explorer..."
        julia --project enhanced_viewer.jl
        ;;
        
    4)
        echo "Installing NCDatasets package..."
        julia --project -e 'using Pkg; Pkg.add("NCDatasets")' > /dev/null 2>&1
        
        echo "Running ultra minimal NetCDF viewer..."
        julia --project ultra_minimal.jl
        ;;
    
    *)
        echo "Invalid choice. Exiting."
        exit 1
        ;;
esac