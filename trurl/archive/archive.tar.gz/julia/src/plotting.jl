function create_plot(data::Array, title::String="", xlabel::String="X", ylabel::String="Y")
    f = Figure(resolution=(800, 600))
    ax = Axis(f[1, 1], title=title, xlabel=xlabel, ylabel=ylabel)
    
    # Handle different dimensionality of data
    if ndims(data) == 1
        lines!(ax, 1:length(data), data)
    elseif ndims(data) == 2
        heatmap!(ax, data)
        Colorbar(f[1, 2], colormap=:viridis)
    elseif ndims(data) == 3
        # Show first slice of 3D data
        heatmap!(ax, data[:, :, 1])
        Colorbar(f[1, 2], colormap=:viridis)
    end
    
    return f
end

function plot_variable(nc_data::NCData, variable::String)
    data = get_variable_data(nc_data, variable)
    return create_plot(data, variable)
end

function save_plot(figure, filename::String)
    save(filename, figure)
    return nothing
end